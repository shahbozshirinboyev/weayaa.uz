// Content Random START
var headings = [
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">O'ktamjon Dilbarov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Back-end Developer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Behind every difficulty there are new opportunities - you just need patience and work to discover them.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/5.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Khamid Seydanov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">3D Designer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">“Today” is your opportunity to build the “Tomorrow” you want.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/4.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Lee Seung Hyun</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Weayaa Korea CEO</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">You are a person who can succeed in anything.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/2.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Choi Youn Soo</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">General Manager</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Success goes to those who are most persistent.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/3.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Tommy Kim</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Weayaa UZ CEO</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">I hope tomorrow will come better than today... U</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/1.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Meyrjan Davronov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Graphic Designer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Fortune always favours the brave, and never helps a man who does not help himself.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/7.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Shahboz Shirinboyev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Graphic Designer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Be stronger than your excuses.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/6.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Nuriddin Akberdiev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Manager</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">The hardest thing is to start taking action, everything else depends only on perseverance.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/9.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Zerda Jursinova</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Front-End Developer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Conquering Algorithms: The Art of Efficient Programming.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/10.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Hello, I'm</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">G'alimjan Anarkulov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Graphic Designer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Those who are united for one goal have incredible power.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/11.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `
];

// Get the contentrandom div
var contentDiv = document.getElementById("contentrandom");

function changeContent() {
    // Generate a random index
    var randomIndex = Math.floor(Math.random() * headings.length);

    // Set the innerHTML of contentrandom div to the randomly selected heading
    contentDiv.innerHTML = headings[randomIndex];
}

// Call changeContent initially to set content when the page loads
changeContent();

// Set interval to change content every 12 seconds (12000 milliseconds)
setInterval(changeContent, 7000);
// Content Random END