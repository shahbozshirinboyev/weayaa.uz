// Content Random START
var headings = [
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Lee Seung Hyun</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">웨야 한국 대표</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">그대는 뭘 해도 될 사람입니다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/2.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Choi Youn Soo</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">총책임자</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">성공은 가장 끈질긴 자에게 돌아간다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/3.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Tommy Kim</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">웨야 우즈베키스탄 대표</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">오늘보다 더 나은 내일이 찾아오길... U</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/1.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Meyrjan Davronov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">그래픽 디자이너</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">행운은 언제나 용감한 사람에게 유리하며, 자신을 돕지 않는 사람은 결코 돕지 않습니다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/7.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Shahboz Shirinboyev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">그래픽 디자이너</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">당신의 변명보다 더 강해지십시오.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/6.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Nuriddin Akberdiev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">관리자</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">가장 어려운 것은 행동을 시작하는 것입니다. 그 밖의 모든 것은 인내에만 달려 있습니다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/9.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Subhiddin Ergashev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">그래픽 디자이너</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">나쁜 삶이 아니라 단지 나쁜 날입니다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/8.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Zerda Jursinova</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">프런트엔드 개발자</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">알고리즘 정복: 효율적인 프로그래밍의 예술.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/10.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>안녕하세요, 저는</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">G'alimjan Anarkulov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">그래픽 디자이너</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">하나의 목표를 위해 뭉친 사람은 놀라운 힘을 가지고 있습니다.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/11.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `
];

// Get the contentrandom div
var contentDiv = document.getElementById("contentrandom");

function changeContent() {
    // Generate a random index
    var randomIndex = Math.floor(Math.random() * headings.length);

    // Set the innerHTML of contentrandom div to the randomly selected heading
    contentDiv.innerHTML = headings[randomIndex];
}

// Call changeContent initially to set content when the page loads
changeContent();

// Set interval to change content every 12 seconds (12000 milliseconds)
setInterval(changeContent, 7000);
// Content Random END