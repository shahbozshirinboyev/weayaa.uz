// Content Random START
var headings = [
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Lee Seung Hyun</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Генеральный директор Weayaa Korea</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Вы человек, который может добиться успеха во всем.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/2.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Choi Youn Soo</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Главный управляющий</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Успех достается тем, кто наиболее настойчив.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/3.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Tommy Kim</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Генеральный директор Weayaa UZB</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Надеюсь, завтра будет лучше, чем сегодня... U</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/1.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Meyrjan Davronov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Графический дизайнер</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Фортуна всегда благоволит храбрым и никогда не помогает тому, кто сам себе не помогает.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/7.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Shahboz Shirinboyev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Графический дизайнер</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Будьте сильнее своих оправданий.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/6.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Nuriddin Akberdiev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Менеджер</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Сложнее всего начать действовать, все остальное зависит только от упорства.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/9.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Subhiddin Ergashev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Графический дизайнер</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Это просто плохой день, а не плохая жизнь.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/8.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,
    
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Zerda Jursinova</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Фронтенд-разработчик</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Победа над алгоритмами: искусство эффективного программирования.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/10.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Привет, Я</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">G'alimjan Anarkulov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Графический дизайнер</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Те, кто объединены одной целью, обладают невероятной силой.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/11.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `    
    ];

// Get the contentrandom div
var contentDiv = document.getElementById("contentrandom");

function changeContent() {
    // Generate a random index
    var randomIndex = Math.floor(Math.random() * headings.length);
    
    // Set the innerHTML of contentrandom div to the randomly selected heading
    contentDiv.innerHTML = headings[randomIndex];
}

// Call changeContent initially to set content when the page loads
changeContent();

// Set interval to change content every 12 seconds (12000 milliseconds)
setInterval(changeContent, 7000);
// Content Random END