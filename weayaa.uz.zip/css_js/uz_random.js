// Content Random START
var headings = [
    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Lee Seung Hyun</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Weayaa Koreya bosh direktori</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Siz hamma narsada muvaffaqiyat qozona oladigan insonsiz.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/2.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Choi Youn Soo</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Bosh menejer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Muvaffaqiyat eng qat'iy bo'lganlarga beriladi.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/3.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Tommy Kim</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Weayaa Uzbekiston bosh direktori</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Umid qilamanki, ertangi kun bugundan yaxshiroq bo'ladi... U</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/1.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Meyrjan Davronov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Grafik dizayner</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Baxt har doim jasurga yordam beradi va o'ziga yordam bermaydigan odamga hech qachon yordam bermaydi.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/7.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Shahboz Shirinboyev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Grafik dizayner</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">O'z bahonalaringizdan kuchliroq bo'ling.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/6.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Nuriddin Akberdiev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Menejer</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Eng qiyin narsa - harakat qilishni boshlash, qolgan hamma narsa faqat qat'iyatga bog'liq.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/9.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Subhiddin Ergashev</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Grafik dizayner</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Bu shunchaki yomon kun, yomon hayot emas.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/8.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `, 

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">Zerda Jursinova</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Front-End dasturchi</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Algoritmlarni zabt etish: samarali dasturlash san'ati.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/10.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `,

    `
                                    <div class="col-sm-6">
                                        <div class="mh-header-info">
                                            <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                                <span>Salom, Men</span>
                                            </div>
                                            
                                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s" style="color: white;">G'alimjan Anarkulov</h2>
                                            <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Grafik dizayner</h4>
                                            <h5 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style="color: white;">Bitta maqsad uchun birlashganlar aql bovar qilmas kuchga ega.</h5>
                                            
                                        </div>
                                    </div>
            
                                    <div class="col-sm-6">
                                        <div class="hero-img wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                            <div class="img-border">
                                                <img src="./caricature_images/11.jpg" alt=""  class="img-fluid">
                                            </div>
                                        </div>
                                    </div>
    `    
    ];

// Get the contentrandom div
var contentDiv = document.getElementById("contentrandom");

function changeContent() {
    // Generate a random index
    var randomIndex = Math.floor(Math.random() * headings.length);
    
    // Set the innerHTML of contentrandom div to the randomly selected heading
    contentDiv.innerHTML = headings[randomIndex];
}

// Call changeContent initially to set content when the page loads
changeContent();

// Set interval to change content every 12 seconds (12000 milliseconds)
setInterval(changeContent, 7000);
// Content Random END